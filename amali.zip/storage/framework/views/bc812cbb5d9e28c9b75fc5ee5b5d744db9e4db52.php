<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <div class="content container-fluid">
        <div class="row justify-content-lg-center">
            <div class="col-lg-10">

                <div class="page-header">
                    <div class="row">
                        <div class="col">
                            <h3 class="page-title">Cable Subscription</h3>
                            <ul class="breadcrumb">
                                <li class=""><a href="<?php echo e(url('dashboard')); ?>">Dashboard</a></li>
                                
                            </ul>
                        </div>
                    </div>
                </div>

                    <div class="card-body">
                        <!--                    <div class="box w3-card-4">-->
                        <div class="row">
                            <div class="col-12 col-md-6 col-lg-4 d-flex">
                                <div class="card flex-fill bg-white">
                                    <img width="150" height="150" alt="Card Image" src="<?php echo e(asset('assets/img/dstv.jpg')); ?>" class="card-img-top">
                                    <div class="card-header">
                                        <h5 class="card-title mb-0 text-center">Dstv Subscription</h5>
                                    </div>
                                    <div class="card-body">
                                        <center>

                                            <a class="btn btn-success" href="#">Select</a>
                                        </center>
                                    </div>
                                </div>
                            </div>


                            <div class="col-12 col-md-6 col-lg-4 d-flex">
                                <div class="card flex-fill bg-white">
                                    <img width="150" height="150" alt="Card Image" src="<?php echo e(asset('assets/img/star.png')); ?>" class="card-img-top">
                                    <div class="card-header">
                                        <h5 class="card-title mb-0 text-center">Startime Subscription</h5>
                                    </div>
                                    <div class="card-body">
                                        <center>

                                            <a class="btn btn-success" href="#">Select</a>
                                        </center>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-md-6 col-lg-4 d-flex">
                                <div class="card flex-fill bg-white">
                                    <img width="150" height="150" alt="Card Image" src="<?php echo e(asset('assets/img/gotv.jpg')); ?>" class="card-img-top">
                                    <div class="card-header">
                                        <h5 class="card-title mb-0 text-center">Electricity</h5>
                                    </div>
                                    <div class="card-body">
                                        <center>
                                            
                                            <a class="btn btn-success" href="#">Select</a>
                                        </center>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script src="<?php echo e(asset('assets/plugins/select2/js/select2.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/plugins/moment/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap-datetimepicker.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables/datatables.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/amalikuli/resources/views/bills/tv.blade.php ENDPATH**/ ?>