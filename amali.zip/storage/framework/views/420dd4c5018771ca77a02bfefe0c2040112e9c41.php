<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <div class="content container-fluid">
            <div class="row">
                
                <div class="col-xl-6 col-sm-6 col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="dash-widget-header">
<span class="dash-widget-icon bg-3">
<i class="fas fa-lock"></i>
</span>
                                <div class="dash-count">
                                    <div class="dash-title">Total Verified<b> ( <?php echo e($verified); ?> )</b></div>
                                     
                                </div>
                                <br>
                                <a href="<?php echo e(route('admin.kycs.successful')); ?>" class="btn btn-primary btn-sm"> View</a>
                            </div> 
                           
                        </div>
                    </div>
                </div>
                <div class="col-xl-6 col-sm-6 col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="dash-widget-header">
<span class="dash-widget-icon bg-1">
<i class="fas fa-unlock"></i>
</span>
                                <div class="dash-count">
                                    <div class="dash-title">Total Unverifed<b> ( <?php echo e($unverified); ?> )</b></div>
                                </div><br>
                                <a href="<?php echo e(route('admin.kycs.rejected')); ?>" class="btn btn-primary btn-sm">View </a>
                            </div> 
                           
                        </div>
                    </div>
                </div>
                 
            </div>
             



            <div class="card-body">
                <form class="form" id="filter_form" method="get">
                    <div class="row">
                        <h5 class="text-secondary"><?php echo e($title); ?></h5>

                        <div class="row">
                            <div class="col-sm-12">
                        <br>
                        

                        <hr>
                                <div class="card card-table">
                                    <div class="card-body">
                                        <div class="table-responsive">
                                        <table class="table table-center table-hover datatable">
                                    <thead class="thead-light">
                                    <tr>
                                        <th>SN</th>
                                        <th>Agent</th>  
                                        <th>Status</th>
                                        <th>Date</th> 
                                        <th>Action</th> 
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                    $user = App\Models\User::whereId($data->user_id)->first();
                                    ?>

                                        <tr>
                                            <td>
                                            <?php echo e($loop->iteration); ?>

                                            </td>
                                            <td>
                                                <?php echo e($user->firstname ?? ""); ?>

                                                <?php echo e($user->lastname ?? ""); ?><br>
                                                <small><?php echo e($user->email ?? ""); ?></small>
                                            </td>  
                                            <td>
                                               <?php if($data->status == 1): ?>
                                                    <span class="badge badge-primary"> Verified </span>
                                                <?php else: ?>
                                                    <span class="badge badge-danger"> Pending </span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php echo e($data->created_at); ?>

                                            </td> 
                                            <td>
                                            <a href="<?php echo e(route('admin.viewkyc',$data->id)); ?>" class="btn btn-primary btn-sm"> 
                                             View
                                            </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('assets/plugins/select2/js/select2.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/plugins/moment/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap-datetimepicker.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables/datatables.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>

    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("admin.layout.sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/amalikuli/resources/views/admin/kyc.blade.php ENDPATH**/ ?>