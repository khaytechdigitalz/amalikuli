<?php $__env->startSection('contents'); ?>
    <div class="loginbox">
        <div class="login-right">
            <div class="login-right-wrap">
                <h1>Login</h1>
                <p class="account-subtitle">Access to Your dashboard</p>

                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.validation-errors','data' => ['class' => 'mb-4 alert-danger alert-dismissible alert']]); ?>
<?php $component->withName('jet-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-4 alert-danger alert-dismissible alert']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>


                <?php if(session('status')): ?>
                    <div class="mb-4 font-medium text-sm text-green-600 alert-dismissible alert">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                    <div class="mb-4 font-medium text-sm alert-danger alert-dismissible alert">
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>

                <?php if(session('success')): ?>
                    <div class="mb-4 font-medium text-sm alert-success alert-dismissible alert">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>


                <form method="POST">
                    <?php echo csrf_field(); ?>

                    <div class="form-group">
                        <label for="phone" class="form-control-label">Phone No</label>
                        <input type="tel" name="phone" id="phone" class="form-control pass-input"
                               value="<?php echo e(old('phone')); ?>" maxlength="11" required autofocus/>
                    </div>
                    <div class="form-group">
                        <label class="form-control-label">Password</label>
                        <div class="pass-group">
                            <input type="password" name="password" class="form-control pass-input" required/>
                            <span class="fas fa-eye toggle-password"></span>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="row">
                            <div class="col-6">
                                <div class="custom-control custom-checkbox">
                                    <input type="checkbox" class="custom-control-input" id="cb1" name="remember">
                                    <label class="custom-control-label" for="cb1">Remember me</label>
                                </div>
                            </div>
                            <div class="col-6 text-end">
                                <?php if(Route::has('password.request')): ?>
                                    <a class="forgot-link" href="<?php echo e(route('password.request')); ?>">Forgot Password ?</a>
                                <?php endif; ?>

                            </div>
                        </div>
                    </div>
                    <button class="btn btn-lg btn-block btn-success w-100" type="submit">Sign-In</button>
                    <div class="login-or">
                        <span class="or-line"></span>
                        
                    </div>

                    
                    
                    
                    

                    <div class="text-center dont-have">Don't have an account yet? <a href="<?php echo e(route('register')); ?>">Register</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/amalikuli/resources/views/auth/login.blade.php ENDPATH**/ ?>