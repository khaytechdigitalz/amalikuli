<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <div class="content container-fluid">

        <div class="page-header">
            <div class="row align-items-center">
                <div class="col">
                    <h3 class="page-title">All Sub-Agents</h3>
                    <ul class="breadcrumb">
                        <li ><a href="<?php echo e(url('admin/dashboard')); ?>">Dashboard</a></li>
                        
                    </ul>
                </div>
            </div>
        </div>

        <div class="card-body">
            <form class="form" id="filter_form" method="get">
                <div class="row">
                   
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card card-table">
                                <div class="card-body">
                                    <div class="table-responsive">
                                    <table class="table table-center table-hover datatable">
                                    <thead class="thead-light">
                                    <tr>
                                        <th >#</th>
                                        <th>Super Agent</th>
                                        <th>Agent Code</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Phone Number</th>
                                        <th>Wallet Balance</th>
                                        <th>Status</th>
                                        <th class="text-right">Actions</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                           <td><?php echo e($loop->iteration); ?></td>
                                            <td>
                                                
                                                <?php
                                                $agent = App\Models\User::whereUuid($user->uuid)->whereSubAgent(null)->first();
                                                ?>
                                                <?php if($agent): ?>
                                                <?php echo e($agent->email); ?><br>
                                                <a  href="<?php echo e(route('admin.view.agent',$agent->id)); ?>" class="btn btn-sm btn-primary">View Super Agent</a>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php echo e($user->uuid."-".$user->id); ?><br>
                                                 
                                            </td>
                                            <td>
                                                <?php echo e($user->firstname); ?> <?php echo e($user->lastname); ?>

                                            </td>
                                            
                                            <td>
                                                <?php echo e($user->email); ?>

                                            </td>
                                            <td>
                                                <?php echo e($user->phone); ?>

                                            </td>
                                            <td>
                                            ₦ <?php echo e($user->wallets[0]->balance); ?>

                                            </td>
                                            <td>
                                                <?php if($user->status == 1): ?>
                                                    <span class="badge badge-primary"> Active </span>
                                                <?php else: ?>
                                                    <span class="badge badge-danger"> De-activated </span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                            <a  href="<?php echo e(route('admin.view.agent',$user->id)); ?>" class="btn btn-sm btn-primary">View Perfomance</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('assets/plugins/select2/js/select2.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/plugins/moment/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap-datetimepicker.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables/datatables.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin/layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/amalikuli/resources/views/admin/all-subagent.blade.php ENDPATH**/ ?>