<?php

namespace App\Http\Controllers;

use App\Mail\NewSubAccountMail;
use App\Models\Transaction;
use App\Models\User;
use App\Models\Wallet;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;

class AgentController extends Controller
{

    public function subAgents()
    {
        $datas['users'] = User::where([["uuid", Auth::user()->uuid], ['sub_agent', 1]])->latest()->get();
        return view('agents', $datas);
    }

    public function searchSubAgents(Request $request)
    {
        $input = $request->all();

        $validator = Validator::make($request->all(), [
            'search' => 'required',
        ]);

        if ($validator->fails()) {
            return back()
                ->withErrors($validator)
                ->withInput();
        }

        $search = $input['search'];

        $datas['users'] = User::where(function ($query) use ($search) {
            $query->orwhere('lastname', 'like', '%' . $search . '%')
                ->orWhere('firstname', 'like', '%' . $search . '%')
                ->orWhere('email', 'like', '%' . $search . '%')
                ->orWhere('phone', 'like', '%' . $search . '%')
                ->Where('uuid', Auth::user()->uuid)
                ->Where('sub_agent', 1);
        })->get();

        return view('agents', $datas);
    }

    public function createSubAgent(Request $request)
    {
        $input = $request->all();

        $validator = Validator::make($request->all(), [
            'firstName' => 'required|max:200',
            'lastName' => 'required|max:200',
            'email' => 'required|max:200|email|unique:users',
            'dob' => 'required|max:200',
            'gender' => 'required|max:200',
            'phone' => 'required|max:11',
            'limit' => 'required',
        ]);

        if ($validator->fails()) {
            return back()
                ->withErrors($validator)
                ->withInput();
        }

        $password = uniqid();

        $u = User::create([
            'firstname' => $input['firstName'],
            'lastname' => $input['lastName'],
            'dob' => $input['dob'],
            'gender' => $input['gender'],
            'phone' => $input['phone'],
            'email' => $input['email'],
            'transaction_limit' => $input['limit'],
            'password' => Hash::make($password),
            'uuid' => Auth::user()->uuid,
            'sub_agent' => 1,
        ]);


        Wallet::create([
            'user_id' => $u->id,
            'name' => 'deposit'
        ]);


        $datas['businessName'] = Auth::user()->name;
        $datas['name'] = $input['lastName'];
        $datas['email'] = $input['email'];
        $datas['phone'] = $input['phone'];
        $datas['password'] = $password;

        try {
            Mail::to($input['email'])->send(new NewSubAccountMail($datas));
        } catch (\Exception $e) {
            echo "Mail error";
        }


        return redirect()->route('addSubAgent')->with("success", "Subagent created successfully. Login credentials has been sent to the email provided.");

    }


    public function performance()
    {
        $datas['date'] = Carbon::now()->format('y-m');
        $datas['users'] = User::where([["uuid", Auth::user()->uuid], ['sub_agent', 1]])->latest()->get();
        return view('settings.performance', $datas);
    }

    public function performanceSearch()
    {
        $datas['users'] = User::where([["uuid", Auth::user()->uuid], ['sub_agent', 1]])->latest()->get();
        return view('settings.performance', $datas);
    }

    public function agentTransactions($id)
    {

        $datas['datas'] = Transaction::where('user_id', $id)->get();
        $datas['tran_count'] = Transaction::where([['user_id', $id], ['created_at', 'LIKE', '%' . Carbon::now()->format('Y-m-d') . '%']])->count();
        $datas['tran_sum'] = Transaction::where([['user_id', $id], ['created_at', 'LIKE', '%' . Carbon::now()->format('Y-m-d') . '%']])->sum('amount');
        $datas['wallet'] = Wallet::where('user_id', $id)->first();

        return view('transactions_per_agent', $datas);
    }

    public function transactions()
    {
        $datas['datas'] = Transaction::where('uuid', Auth::user()->uuid)->get();

        return view('transactions', $datas);
    }


}
