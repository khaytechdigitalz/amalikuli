<?php

namespace App\Http\Controllers;

use App\Models\Terminal;
use Illuminate\Support\Facades\Auth;

class PosManagementController extends Controller
{
    public function terminals()
    {
        $datas['datas'] = Terminal::where('agent_id', Auth::id())->get();
        $datas['i'] = 1;

        return view('terminals', $datas);
    }
}
