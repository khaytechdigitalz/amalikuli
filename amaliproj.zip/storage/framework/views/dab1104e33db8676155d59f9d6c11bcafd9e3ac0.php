<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <title>Amali</title>

    <link rel="shortcut icon" href="<?php echo e(asset('assets/img/lg.png')); ?>">

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/fontawesome/css/fontawesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/fontawesome/css/all.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
<!--[if lt IE 9]>
    <script src="<?php echo e(asset('assets/js/html5shiv.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/respond.min.js')); ?>"></script>
    <![endif]-->

    <link href="https://fonts.googleapis.com/css?family=Karla:400,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(('https://cdn.materialdesignicons.com/4.8.95/css/materialdesignicons.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(('https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('pa/css/bd-wizard.css')); ?>">
</head>
<body>

<div class="main-wrapper login-body">
    <div class="login-wrapper">
        <div class="container">
            <img class="img-fluid logo-dark mb-2" src="<?php echo e(asset('assets/img/lg.png')); ?>" alt="Logo">
            <?php echo $__env->yieldContent('contents'); ?>
        </div>
    </div>
</div>


<script src="<?php echo e(asset('assets/js/jquery-3.6.0.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/js/feather.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>

<script src="<?php echo e(('https://code.jquery.com/jquery-3.4.1.min.js')); ?>"></script>
<script src="<?php echo e(('https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js')); ?>"></script>
<script src="<?php echo e(('https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('pa/js/jquery.steps.min.js')); ?>"></script>
<script src="<?php echo e(asset('pa/js/bd-wizard.js')); ?>"></script>

</body>

</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/amalikuli/resources/views/layouts/auth.blade.php ENDPATH**/ ?>