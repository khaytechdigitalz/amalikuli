<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/datatables/datatables.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <div class="content container-fluid">

            <div class="page-header">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="page-title">Terminals</h3>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

 
            <div class="row">
                <div class="col-sm-12">
                                    <?php if(session('status')): ?>
                                        <div class="mb-4 font-medium text-sm text-green-600 alert-dismissible alert">
                                            <?php echo e(session('status')); ?>

                                        </div>
                                    <?php endif; ?>

                                    <?php if(session('error')): ?>
                                        <div class="mb-4 font-medium text-sm alert-danger alert-dismissible alert">
                                            <?php echo e(session('error')); ?>

                                        </div>
                                    <?php endif; ?>

                                    <?php if(session('success')): ?>
                                        <div class="mb-4 font-medium text-sm alert-success alert-dismissible alert">
                                            <?php echo e(session('success')); ?>

                                        </div>
                                    <?php endif; ?>


                    <div class="card card-table">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-center table-hover datatable">
                                    <thead class="thead-light">
                                    <tr>
                                        <th>SN</th>
                                        <th>Terminal ID</th> 
                                        <th>Serial Number</th> 
                                        <th>Sub Agent Assigned</th>
                                        <th>Status</th>
                                        <th>Date</th>
                                        <th class="text-right">Actions</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php echo e($i++); ?>

                                            </td> 
                                            <td>
                                                <?php echo e($data->terminal_id); ?>

                                            </td>
                                            <td>
                                                <?php echo e($data->serial_number); ?>

                                            </td> 
                                            <td>
                                            <?php echo e(@App\Models\User::whereId($data->sub_agent_id)->first()->firstname ?? "Not Assigned"); ?> 
                                            <?php echo e(@App\Models\User::whereId($data->sub_agent_id)->first()->lastname ?? "Not Assigned"); ?>

                                          
                                            </td>
                                            <td>
                                                <?php if($data->status == 1): ?>
                                                    <span class="badge badge-primary"> Active </span>
                                                <?php else: ?>
                                                    <span class="badge badge-danger"> Not Active</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php echo e($data->created_at); ?>

                                            </td>
                                            <td class="text-right ">
                                                <button  data-toggle="modal" data-target="#myModal<?php echo e($data->id); ?>" class="btn btn-sm btn-primary">Assign</button>
                                            </td>
                                        </tr>


<!-- The Modal -->
<div class="modal" id="myModal<?php echo e($data->id); ?>">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Assign Terminal</h4><br>
      </div>

      <br>

      <div class="modal-header">
      <a class="text-danger">
        Please ensure you check very well before assigning Terminal to a sub agent. We will not be liable to any loss arising from you assigning Terminal to a wrong sub agent
        </a>
      </div>
      <form action="" method="POST">
      <?php echo csrf_field(); ?>
      <!-- Modal body -->
      <div class="modal-body">
        <div class="form-group">
        <label>Select Sub Agent</label>
        <select  name="agent" class="form-control">
        <option  select disabled>Please Select A Sub Agent</option>
        <?php $__currentLoopData = $subagent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($datas->id); ?>"><?php echo e($datas->firstname); ?> <?php echo e($datas->lastname); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select> 
      </div>

      <div class="form-group">
        <label>Serial Number</label>
        <input name="serialnumber" value="<?php echo e($data->serial_number); ?>" readonly class="form-control" >
        </div>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Assign</button>
      </div>
    </form>

    </div>
  </div>
</div>
<!-- END MODAL-->

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('assets/plugins/select2/js/select2.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/plugins/moment/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap-datetimepicker.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables/datatables.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>

    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/amalikuli/resources/views/terminals.blade.php ENDPATH**/ ?>