<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <div class="content container-fluid">
        <div class="row justify-content-lg-center">
            <div class="col-lg-12">

                <div class="page-header">
                    <div class="row">
                        <div class="col">
                            <h3 class="page-title">View Document</h3>  
                        </div>
                    </div>
                </div>

                    <div class="card-body">
                        <!--                    <div class="box w3-card-4">-->
                        <a href="<?php echo e(route('admin.kyc.approve',$kyc->id)); ?>" class="btn btn-primary btn-sm"> Approve KYC</a>
                        <a href="<?php echo e(route('admin.kyc.reject',$kyc->id)); ?>" class="btn btn-danger btn-sm"> Reject KYC</a><hr>
                        <?php
                                    $user = App\Models\User::whereId($kyc->user_id)->first();
                                    ?>
                         <b>   Agent Name: <?php echo e($user->firstname ?? ""); ?> <?php echo e($user->lastname ?? ""); ?><br>
                            Agent Email: <?php echo e($user->email ?? ""); ?><br>
                            Agent Phone: <?php echo e($user->phone ?? ""); ?><br>
                            Agent KYC Status: <?php if($kyc->status == 1): ?> <a class="text-success">Approved</a> <?php elseif($kyc->status == 2): ?>  <a class="text-danger">Rejected</a> <?php else: ?> <a class="text-warning">Pending</a> <?php endif; ?><br></b></b>

<br>          
<?php if(session('status')): ?>
                                        <div class="mb-4 font-medium text-sm text-green-600 alert-dismissible alert">
                                            <?php echo e(session('status')); ?>

                                        </div>
                                    <?php endif; ?>

                                    <?php if(session('error')): ?>
                                        <div class="mb-4 font-medium text-sm alert-danger alert-dismissible alert">
                                            <?php echo e(session('error')); ?>

                                        </div>
                                    <?php endif; ?>

                                    <?php if(session('success')): ?>
                                        <div class="mb-4 font-medium text-sm alert-success alert-dismissible alert">
                                            <?php echo e(session('success')); ?>

                                        </div>
                                    <?php endif; ?>
                                                  <div class="row">
                       
                            <div class="col-12 col-md-6 col-lg-6 d-flex">
                                <div class="card flex-fill bg-white">
                                    <img width="150" height="150" alt="Card Image" src="<?php echo e(asset($kyc->utility)); ?>" class="card-img-top">
                                    <div class="card-header">
                                        <h5 class="card-title mb-0 text-center">Utility Bill </h5>
                                                                            </div>
                                    <div class="card-body">
                                        <center>
                                            <a class="btn btn-sm  btn-success" href="<?php echo e(asset($kyc->utility)); ?>" download>Download</a>
                                        </center>
                                    </div>
                                </div>
                            </div>




                            <div class="col-12 col-md-6 col-lg-6 d-flex">
                                <div class="card flex-fill bg-white">
                                    <img width="150" height="150" alt="Card Image" src="<?php echo e(asset($kyc->idcard)); ?>" class="card-img-top">
                                    <div class="card-header">
                                        <h5 class="card-title mb-0 text-center">ID Card</h5>
                                    </div>
                                    <div class="card-body">
                                        <center>
                                            <a class="btn  btn-sm btn-success" href="<?php echo e(asset($kyc->idcard)); ?>" download>Download</a>
                                        </center>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-md-6 col-lg-6 d-flex">
                                <div class="card flex-fill bg-white">
                                  <!--  <img width="150" height="150" alt="Card Image" src="<?php echo e(asset($kyc->guarantorform)); ?>" class="card-img-top">-->
                                    <div class="card-header">
                                        <h5 class="card-title mb-0 text-center">Guarantor's ID</h5>
                                    </div>
                                    <div class="card-body">
                                        <center>
                                            <a class="btn  btn-sm btn-success" href="<?php echo e(asset($kyc->guarantorform)); ?>" download>Download</a>
                                        </center>
                                    </div>
                                </div>
                            </div>

                            <div class="col-12 col-md-6 col-lg-6 d-flex">
                                <div class="card flex-fill bg-white">
                                    <img width="150" height="150" alt="Card Image" src="<?php echo e(asset($kyc->passport)); ?>" class="card-img-top">
                                    <div class="card-header">
                                        <h5 class="card-title mb-0 text-center">Passport</h5>
                                    </div>
                                    <div class="card-body">
                                        <center>
                                            <a class="btn btn-sm btn-success" href="<?php echo e(asset($kyc->passport)); ?>" download>Download</a>
                                        </center>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('assets/plugins/select2/js/select2.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/plugins/moment/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap-datetimepicker.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables/datatables.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>
 
<?php $__env->stopSection(); ?>

<?php echo $__env->make("admin.layout.sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/amalikuli/resources/views/admin/view-kyc.blade.php ENDPATH**/ ?>