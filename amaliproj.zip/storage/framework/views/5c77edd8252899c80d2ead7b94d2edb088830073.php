<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <div class="content container-fluid">

            <div class="page-header">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="page-title">Performance Report</h3>
                        <ul class="breadcrumb">
                            <li><a href="<?php echo e(url('dashboard')); ?>">Dashboard</a></li>
                            
                        </ul>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <form class="form" id="filter_form" method="get">
                    <div class="row">
                        <!-- search -->

                        <div class="card">


                            <div class="card-body">
                                <form method="POST" action="<?php echo e(route('agent.performanceSearch')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-4">
                                            <select name="month" class="form-select">
                                                <option value="01">January</option>
                                                <option value="02">February</option>
                                                <option value="03">March</option>
                                                <option value="04">April</option>
                                                <option value="05">May</option>
                                                <option value="06">June</option>
                                                <option value="07">July</option>
                                                <option value="08">August</option>
                                                <option value="09">September</option>
                                                <option value="10">October</option>
                                                <option value="11">November</option>
                                                <option value="12">December</option>
                                            </select>
                                        </div>
                                        <div class="col-4">
                                            <select name="year" class="form-select">
                                                <?php
                                                    $current=date('Y');
                                                    $loop=10;
                                                ?>

                                                <?php for($i=0; $i < $loop; $i++): ?>
                                                    <option value="<?php echo e($current-$i); ?>"><?php echo e($current-$i); ?></option>
                                                <?php endfor; ?>
                                            </select>
                                        </div>
                                        <div class="col-4">
                                            <label class="text-success"></label>
                                            <input type="submit" class="btn btn-secondary" value="Fetch" name="submit">
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="card card-table">
                                        <div class="card-body">
                                            <div class="table-responsive">
                                                <table class="table table-center table-hover datatable">
                                                    <thead class="thead-light">
                                                    <tr>
                                                        <th>Agent Name</th>
                                                        <th>Agent Phone Number</th>
                                                        <th>Transaction Volume</th>
                                                        <th>Transaction Count</th>
                                                        <th>Total Amount</th>
                                                        <th>Total Count</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($user->firstname); ?> <?php echo e($user->lastname); ?></td>
                                                            <td><?php echo e($user->phone); ?></td>
                                                            <td><?php echo e(\App\Models\Transaction::where([['user_id', $user->id], []])->sum('amount')); ?></td>
                                                            <td><?php echo e(\App\Models\Transaction::where('user_id', $user->id)->count()); ?></td>
                                                            <td><?php echo e(\App\Models\Transaction::where('user_id', $user->id)->sum('amount')); ?></td>
                                                            <td><?php echo e(\App\Models\Transaction::where('user_id', $user->id)->count()); ?></td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('assets/plugins/select2/js/select2.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/plugins/moment/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap-datetimepicker.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables/datatables.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/amalikuli/resources/views/settings/performance.blade.php ENDPATH**/ ?>