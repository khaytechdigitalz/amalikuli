<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <div class="content container-fluid">
            <div class="row justify-content-lg-center">
                <div class="col-lg-10">

                    <div class="page-header">
                        <div class="row">
                            <div class="col">
                                <h3 class="page-title">Profile</h3>
                                <ul class="breadcrumb">
                                    
                                    
                            </ul>
                        </div>
                    </div>
                    </div>
                    <div class="row">
                        <div class="col-xl-9 col-md-8">
                            <?php echo $__env->make('error_success_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <div class="card">
                                <div class="card-header">
                                    <h5 class="card-title">Basic information</h5>
                                </div>
                                <div class="card-body">

                                    <form method="POST" action="<?php echo e(route('update-profile')); ?>">
                                        <?php echo csrf_field(); ?>
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        <div class="row form-group">
                                            <label for="name" class="col-sm-3 col-form-label input-label">Name</label>
                                            <div class="col-sm-4">
                                                <input type="text" class="form-control" name="lastname"
                                                       placeholder="Last Name"
                                                       value="<?php echo e(\Illuminate\Support\Facades\Auth::user()->lastname); ?>">
                                            </div>
                                            <div class="col-sm-4">
                                                <input type="text" class="form-control" name="firstname"
                                                       placeholder="First Name"
                                                       value="<?php echo e(\Illuminate\Support\Facades\Auth::user()->firstname); ?>">
                                            </div>
                                        </div>
                                        <div class="row form-group">
                                            <label for="email" class="col-sm-3 col-form-label input-label">Email</label>
                                            <div class="col-sm-9">
                                                <input type="email" class="form-control" name="email" id="email"
                                                       placeholder="Email"
                                                       value="<?php echo e(\Illuminate\Support\Facades\Auth::user()->email); ?>">
                                            </div>
                                        </div>
                                        <div class="row form-group">
                                            <label for="phone" class="col-sm-3 col-form-label input-label">Phone</label>
                                            <div class="col-sm-9">
                                                <input type="text" class="form-control" id="phone"
                                                       placeholder="xxxx-xxx-xxxx"
                                                       value="<?php echo e(\Illuminate\Support\Facades\Auth::user()->phone); ?>"
                                                       readonly>
                                            </div>
                                        </div>
                                        <div class="row form-group">
                                            <label for="addressline1" class="col-sm-3 col-form-label input-label">Business
                                                Name</label>
                                            <div class="col-sm-9">
                                                <input type="text" class="form-control" id="addressline1"
                                                       placeholder="Your address"
                                                       value="<?php echo e(\Illuminate\Support\Facades\Auth::user()->business->name ?? \App\Models\User::where([['uuid', \Illuminate\Support\Facades\Auth::user()->uuid], ['sub_agent', NULL]])->first()->business->name); ?>"
                                                       readonly>
                                            </div>
                                        </div>
                                        <div class="row form-group">
                                            <label for="addressline1" class="col-sm-3 col-form-label input-label">Business
                                                Address</label>
                                            <div class="col-sm-9">
                                                <input type="text" class="form-control" id="addressline1"
                                                       placeholder="Your address"
                                                       value="<?php echo e(\Illuminate\Support\Facades\Auth::user()->business->address ?? \App\Models\User::where([['uuid', \Illuminate\Support\Facades\Auth::user()->uuid], ['sub_agent', NULL]])->first()->business->name); ?>"
                                                       readonly>
                                            </div>
                                        </div>
                                        <div class="text-end">
                                            <button type="submit" class="btn btn-primary">Save Changes</button>
                                        </div>
                                    </form>

                                </div>
                            </div>
                        </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('assets/plugins/select2/js/select2.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/plugins/moment/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/bootstrap-datetimepicker.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables/datatables.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/slimscroll/jquery.slimscroll.min.js')); ?>"></script>


<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/amalikuli/resources/views/settings/pro.blade.php ENDPATH**/ ?>