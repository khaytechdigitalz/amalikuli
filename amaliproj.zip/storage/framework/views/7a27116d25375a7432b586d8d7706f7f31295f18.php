<?php echo e($slot); ?>

<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/amalikuli/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>