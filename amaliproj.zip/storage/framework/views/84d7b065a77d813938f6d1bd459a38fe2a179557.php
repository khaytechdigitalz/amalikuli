<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <div class="content container-fluid">

            <div class="page-header">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="page-title">All Agents</h3>
                        <ul class="breadcrumb">
                            <li ><a href="<?php echo e(url('admin/dashboard')); ?>">Dashboard</a></li>
                            
                        </ul>
                    </div>
                </div>
            </div>

            <div class="card-body">
                <form class="form" id="filter_form" method="get">
                    <div class="row">
                        <!-- search -->









                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="card card-table">
                                        <div class="card-body">
                                            <div class="table-responsive">
                                                <table class="table table-center table-hover datatable">
                                                    <thead class="thead-light">
                                                    <tr>
                                                        <th>Agent Code</th>
                                                        <th>Name</th>
                                                        <th>Terminals</th>
                                                        <th>Business Phone</th>
                                                        <th>Email</th>
                                                        <th>Date Registered</th>
                                                        <th>Action</th>
                                                    </tr>
                                                   
                                                    </thead>
                                                    <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                    $i = 1;
                                                    $terminal = App\Models\Terminal::whereAgentId($data->id)->count();
                                                    ?>
                                                    <tr> 
                                                        <td><?php echo e($data->uuid); ?></td>
                                                        <td><?php echo e($data->firstname. " " .$data->lastname); ?></td>
                                                        <td><?php echo e($terminal); ?></td>
                                                        <td><?php echo e($data->phone); ?></td>
                                                        <td><?php echo e($data->email); ?></td>
                                                        <td><?php echo e($data->created_at); ?></td>
                                                        <td><a  href="<?php echo e(route('admin.view.agent',$data->id)); ?>" class="btn btn-sm btn-primary">View</a></td>
                                                    </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                </form>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('assets/plugins/select2/js/select2.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/plugins/moment/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap-datetimepicker.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables/datatables.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin/layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/amalikuli/resources/views/admin/all-agent.blade.php ENDPATH**/ ?>