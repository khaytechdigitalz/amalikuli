<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <div class="content container-fluid">
        <div class="row justify-content-lg-center">
            <div class="col-lg-12">

                     
                            <h4 class="page-title">General Settings</h4>  
                       
             
                    <div class="card-body">
                    <?php if(session('status')): ?>
                                        <div class="mb-4 font-medium text-sm text-green-600 alert-dismissible alert">
                                            <?php echo e(session('status')); ?>

                                        </div>
                                    <?php endif; ?>

                                    <?php if(session('error')): ?>
                                        <div class="mb-4 font-medium text-sm alert-danger alert-dismissible alert">
                                            <?php echo e(session('error')); ?>

                                        </div>
                                    <?php endif; ?>

                                    <?php if(session('success')): ?>
                                        <div class="mb-4 font-medium text-sm alert-success alert-dismissible alert">
                                            <?php echo e(session('success')); ?>

                                        </div>
                                    <?php endif; ?>
                                    <br>
                    <form action="" method="POST">
                        <?php echo csrf_field(); ?>

                        <hr>
                        <b>SYSTEM SETTINGS</b>
                            <hr>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group  mb-1">
                                    <label class="form-control-label font-weight-bold"> <?php echo app('translator')->get('Site Title'); ?> </label>
                                    <input class="form-control form-control-lg" type="text" name="sitename" value="<?php echo e($general->sitename); ?>">
                                </div>
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group  mb-1">
                                    <label class="form-control-label font-weight-bold"><?php echo app('translator')->get('Currency'); ?></label>
                                    <input class="form-control form-control-lg" type="text" name="cur_text" value="<?php echo e($general->cur_text); ?>">
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group  mb-1">
                                    <label class="form-control-label font-weight-bold"><?php echo app('translator')->get('Currency Symbol'); ?> </label>
                                    <input class="form-control form-control-lg" type="text" name="cur_sym" value="<?php echo e($general->cur_sym); ?>">
                                </div>
                            </div>
                        </div>
                        <hr>
                        <b>FLOAT SETTINGS</b>
                            <hr>
                            <div class="row">


                            <div class="form-group col-md-12">
                                <div class="form-group  mb-1">
                                    <label class="form-control-label font-weight-bold"><?php echo app('translator')->get('Float Minimum Amount'); ?> (<?php echo e($general->cur_sym); ?>)</label>
                                    <input class="form-control form-control-lg" type="text" name="float_min" value="<?php echo e($general->float_min_amount); ?>">
                                </div>
                            </div>


                            <div class="form-group col-md-12">
                                <div class="form-group  mb-1">
                                    <label class="form-control-label font-weight-bold"><?php echo app('translator')->get('Float Maximum Amount'); ?> (<?php echo e($general->cur_sym); ?>)</label>
                                    <input class="form-control form-control-lg" type="text" name="float_max" value="<?php echo e($general->float_max_amount); ?>">
                                </div>
                            </div>
                            
                            <div class="form-group col-md-12">
                                <div class="form-group  mb-1">
                                    <label class="form-control-label font-weight-bold"><?php echo app('translator')->get('Float Minimum Daily Transaction'); ?>  <?php echo e($general->cur_sym); ?></label>
                                    <input class="form-control form-control-lg" type="text" name="float_min_trx" value="<?php echo e($general->float_min_trx); ?>">
                                </div>
                            </div>
                            <div class="form-group col-md-12">
                                <div class="form-group  mb-1">
                                    <label class="form-control-label font-weight-bold"><?php echo app('translator')->get('Float Minimum Daily Transaction Count'); ?> </label>
                                    <input class="form-control form-control-lg" type="text" name="float_min_count" value="<?php echo e($general->float_min_count); ?>">
                                </div>
                            </div>
                            <div class="form-group col-md-12">
                                <div class="form-group  mb-1">
                                    <label class="form-control-label font-weight-bold"><?php echo app('translator')->get('Float Minimum Agent Months'); ?> </label>
                                    <input class="form-control form-control-lg" type="text" name="float_min_month" value="<?php echo e($general->float_min_month); ?>">
                                </div>
                            </div>
                            <div class="form-group col-md-12">
                                <div class="form-group  mb-1">
                                    <label class="form-control-label font-weight-bold"><?php echo app('translator')->get('Float Minimum Tenure'); ?> (Days)</label>
                                    <input class="form-control form-control-lg" type="text" name="float_min_tenure" value="<?php echo e($general->float_min_tenure); ?>">
                                </div>
                            </div>
                            <div class="form-group col-md-12">
                                <div class="form-group  mb-1">
                                    <label class="form-control-label font-weight-bold"><?php echo app('translator')->get('Float Minimum Tenure'); ?> (Days) </label>
                                    <input class="form-control form-control-lg" type="text" name="float_max_tenure" value="<?php echo e($general->float_max_tenure); ?>">
                                </div>
                            </div>
                            <div class="form-group col-md-12">
                                <div class="form-group  mb-1">
                                    <label class="form-control-label font-weight-bold"><?php echo app('translator')->get('Float Interest'); ?> (Flat)</label>
                                    <input class="form-control form-control-lg" type="text" name="float_int_flat" value="<?php echo e($general->float_int_flat); ?>">
                                </div>
                            </div>
                            <div class="form-group col-md-12">
                                <div class="form-group  mb-1">
                                    <label class="form-control-label font-weight-bold"><?php echo app('translator')->get('Float Interest'); ?> (%)</label>
                                    <input class="form-control form-control-lg" type="text" name="float_int_percent" value="<?php echo e($general->float_int_percent); ?>">
                                </div>
                            </div>
                            <div class="form-group col-md-12">
                                <div class="form-group  mb-1">
                                    <label class="form-control-label font-weight-bold"><?php echo app('translator')->get('Float Processing Fee'); ?> (<?php echo e($general->cur_sym); ?>)</label>
                                    <input class="form-control form-control-lg" type="text" name="float_fee" value="<?php echo e($general->float_fee); ?>">
                                </div>
                            </div>


                            
                        </div>
                        <br>
                         

                        <div class="form-group">
                        <br>
                            <button type="submit" class="btn text-white btn-primary btn-block btn-sm"><?php echo app('translator')->get('Update Settings'); ?></button>
                        </div>
                    </form>
                    </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('assets/plugins/select2/js/select2.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/plugins/moment/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap-datetimepicker.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables/datatables.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>
 
<?php $__env->stopSection(); ?>

<?php echo $__env->make("admin.layout.sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/amalikuli/resources/views/admin/settings.blade.php ENDPATH**/ ?>